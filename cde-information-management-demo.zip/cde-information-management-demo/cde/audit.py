"""Quality checks for the document register.

Each check returns findings of the form:
    record_id, file_name, check, severity, field, message, suggested_action, auto_fixable
The audit only looks at the register itself; it never sees the generator's ground truth.
"""

from __future__ import annotations

import re
from collections import defaultdict
from datetime import date

from .standard import REQUIRED_FIELDS, Standard

FINDING_FIELDS = [
    "record_id",
    "file_name",
    "check",
    "severity",
    "field",
    "message",
    "suggested_action",
    "auto_fixable",
]

CHECKS = {
    "filename_pattern": ("Medium", "File name does not follow the naming standard"),
    "filename_metadata_mismatch": ("High", "File name disagrees with the register metadata"),
    "unknown_code": ("Medium", "A code is not in the approved code lists"),
    "missing_metadata": ("Medium", "Required metadata is blank"),
    "status_consistency": ("High", "Status, suitability and revision do not agree"),
    "duplicate_number": ("High", "Two records share a document number and revision"),
    "duplicate_content": ("Medium", "Identical content filed under different numbers"),
    "overdue_review": ("Medium", "Review date has passed"),
    "date_error": ("Low", "Dates are invalid or out of order"),
    "personal_data_classification": ("High", "Personal data is not classed as Restricted"),
    "retention_class": ("Low", "Retention class does not match the document type"),
}

_REVISION_RE = re.compile(r"^[PC]\d{2}$")


def _parse_date(value: str) -> date | None:
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def audit(records: list[dict], std: Standard, as_of: date) -> list[dict]:
    findings: list[dict] = []

    def add(rec, check, field, message, action, auto=False):
        findings.append(
            {
                "record_id": rec["record_id"],
                "file_name": rec.get("file_name", ""),
                "check": check,
                "severity": CHECKS[check][0],
                "field": field,
                "message": message,
                "suggested_action": action,
                "auto_fixable": "Y" if auto else "N",
            }
        )

    for rec in records:
        status = rec.get("status", "")

        # 1. Required metadata present
        missing = [f for f in REQUIRED_FIELDS if not (rec.get(f) or "").strip()]
        if status != "ARCHIVED" and not (rec.get("review_due") or "").strip():
            missing.append("review_due")
        if missing:
            add(rec, "missing_metadata", ";".join(missing),
                f"Missing required field(s): {', '.join(missing)}",
                "Ask the author or owner to complete the metadata")

        # 2. File name follows the standard
        parsed = std.parse_filename(rec.get("file_name", ""))
        if parsed is None:
            fix = std.suggest_filename_fix(rec)
            if fix:
                add(rec, "filename_pattern", "file_name",
                    f"'{rec.get('file_name', '')}' does not match the pattern; expected '{fix}'",
                    "Rename to the expected file name", auto=True)
            else:
                add(rec, "filename_pattern", "file_name",
                    f"'{rec.get('file_name', '')}' does not match the naming pattern",
                    "Author to confirm the correct document number and rename")
        else:
            # 3. File name agrees with metadata
            differing = [f for f in ("originator", "section", "doc_type", "discipline", "number", "revision")
                         if parsed[f] != rec.get(f, "")]
            if differing:
                add(rec, "filename_metadata_mismatch", ";".join(differing),
                    "File name and metadata disagree on: " + ", ".join(differing),
                    "Check which is correct, then correct the file name or the register entry")

        # 4. Codes are on the approved lists
        unknown = []
        for field, valid in (("originator", std.originators), ("section", std.sections),
                             ("doc_type", std.types), ("discipline", std.disciplines),
                             ("suitability", std.suitability)):
            value = rec.get(field, "")
            if value and value not in valid:
                unknown.append(f"{field}={value}")
        if rec.get("status") and rec["status"] not in std.statuses:
            unknown.append(f"status={rec['status']}")
        if rec.get("revision") and not _REVISION_RE.match(rec["revision"]):
            unknown.append(f"revision={rec['revision']}")
        if unknown:
            add(rec, "unknown_code", ";".join(u.split("=")[0] for u in unknown),
                "Code not in the approved lists: " + ", ".join(unknown),
                "Information Manager to confirm whether a new code is needed or the entry is wrong")

        # 5. Status, suitability and revision agree
        rule = std.status_rules.get(status)
        if rule:
            problems = []
            if rule["suitability"] and rec.get("suitability") in std.suitability \
                    and rec["suitability"] not in rule["suitability"]:
                problems.append(f"suitability {rec['suitability']} not allowed for {status}")
            prefix = (rec.get("revision") or "")[:1]
            if rule["revision_prefix"] and _REVISION_RE.match(rec.get("revision", "")) \
                    and prefix != rule["revision_prefix"]:
                problems.append(f"revision {rec['revision']} should start with {rule['revision_prefix']} for {status}")
            if problems:
                add(rec, "status_consistency", "status;suitability;revision", "; ".join(problems),
                    "Author to correct the status, suitability or revision")

        # 8. Review overdue
        due = _parse_date(rec.get("review_due", ""))
        if status != "ARCHIVED" and due and due < as_of:
            add(rec, "overdue_review", "review_due",
                f"Review was due {due.isoformat()} ({(as_of - due).days} days overdue)",
                "Owner to review the document and set a new review date")

        # 9. Dates valid and in order
        created, modified = _parse_date(rec.get("created", "")), _parse_date(rec.get("last_modified", ""))
        date_problems = []
        for field in ("created", "last_modified", "review_due"):
            if (rec.get(field) or "").strip() and _parse_date(rec[field]) is None:
                date_problems.append(f"{field} is not a valid ISO date")
        if created and modified and modified < created:
            date_problems.append("last_modified is earlier than created")
        if created and created > as_of:
            date_problems.append("created is in the future")
        if date_problems:
            add(rec, "date_error", "created;last_modified", "; ".join(date_problems),
                "Owner to correct the dates")

        # 10. Personal data must be Restricted
        if rec.get("contains_personal_data") == "Y" and rec.get("classification") != "Restricted":
            add(rec, "personal_data_classification", "classification",
                f"Flagged as containing personal data but classified '{rec.get('classification', '')}'",
                "Set classification to Restricted", auto=True)

        # 11. Retention class matches document type
        expected = std.expected_retention(rec.get("doc_type", ""))
        if expected and rec.get("retention_class") != expected:
            add(rec, "retention_class", "retention_class",
                f"Retention class is '{rec.get('retention_class', '')}' but {rec['doc_type']} documents use {expected}",
                f"Set retention class to {expected}", auto=True)

    # 6. Duplicate document number and revision
    groups = defaultdict(list)
    for rec in records:
        key = tuple(rec.get(f, "") for f in ("originator", "section", "doc_type", "discipline", "number", "revision"))
        if all(key):
            groups[key].append(rec)
    for members in groups.values():
        if len(members) > 1:
            ids = ", ".join(m["record_id"] for m in members)
            for rec in members:
                add(rec, "duplicate_number", "number;revision",
                    f"Same number and revision used by {ids}",
                    "Information Manager to reissue one number and reconcile the content")

    # 7. Same content under different numbers
    by_hash = defaultdict(list)
    for rec in records:
        if (rec.get("content_hash") or "").strip():
            by_hash[rec["content_hash"]].append(rec)
    for members in by_hash.values():
        if len(members) > 1:
            ids = ", ".join(m["record_id"] for m in members)
            for rec in members:
                add(rec, "duplicate_content", "content_hash",
                    f"Identical content also filed as {ids}",
                    "Keep one master copy and archive or link the other")

    findings.sort(key=lambda f: (f["record_id"], f["check"]))
    return findings
