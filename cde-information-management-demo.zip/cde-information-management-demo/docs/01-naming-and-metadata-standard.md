# 01. Naming and metadata standard

Project: Marlow Valley Tunnel Scheme (a fictional project used for this demonstration).
Machine-readable version: [`config/standard.json`](../config/standard.json). The audit code reads that file, so
changing a code list there changes what the checks accept.

This standard is modelled on the ideas in ISO 19650 (information management using building information
modelling): a consistent file name built from coded fields, a status and suitability for every document, and
a revision scheme that separates work in progress from published information. It is simplified for the demo
and is not a copy of any organisation's standard.

## 1. File name

```
MVT-ARC-S3-DR-CV-0012_P02.pdf
|   |   |  |  |  |    |   |
|   |   |  |  |  |    |   +-- file extension (lower case)
|   |   |  |  |  |    +------ revision (P01..P99 or C01..C99)
|   |   |  |  |  +----------- document number (4 digits)
|   |   |  |  +-------------- discipline code
|   |   |  +----------------- document type code
|   |   +-------------------- section code
|   +------------------------ originator code
+---------------------------- project code (always MVT)
```

Rules:

- Fields are separated by hyphens. The revision is separated from the number by one underscore.
- Codes are upper case. The extension is lower case.
- No spaces and no extra words (for example `FINAL` or `copy`). Status belongs in metadata, not in the name.
- The document number is unique within the same originator, section, type and discipline.

Regular expression used by the audit:

```
^MVT-[A-Z]{3}-[A-Z0-9]{2}-[A-Z]{2}-[A-Z]{2}-\d{4}_[PC]\d{2}\.[a-z0-9]{2,4}$
```

## 2. Code lists

**Originator**

| Code | Organisation (fictional) |
|---|---|
| ARC | Arden Civil Design |
| KTL | Kestrel Tunnelling |
| FGS | Fieldgate Surveys |
| MVC | Marlow Valley Constructors |
| CLT | Client team |

**Section**

| Code | Meaning |
|---|---|
| S1 to S6 | Tunnel sections 1 to 6 |
| ZZ | Project-wide |

**Document type**

| Code | Meaning | Code | Meaning |
|---|---|---|---|
| DR | Drawing | CA | Calculation |
| RP | Report | LT | Letter |
| MS | Method statement | MI | Meeting minutes |
| SP | Specification | RA | Risk assessment |

**Discipline**

| Code | Meaning | Code | Meaning |
|---|---|---|---|
| CV | Civil | PM | Project management |
| ST | Structural | SU | Survey |
| GE | Geotechnical | EN | Environmental |
| ME | Mechanical | HS | Health and safety |
| EL | Electrical | | |

New codes are added only by the Information Manager, in `config/standard.json`, with a note in the change log.

## 3. Status, suitability and revision

Every document has a CDE status, a suitability code and a revision. They must agree.

| Status | Meaning | Allowed suitability | Revision prefix |
|---|---|---|---|
| WIP | Being worked on by its author, not visible to others | S0 | P |
| SHARED | Visible to the project team for coordination or comment | S1, S2, S3 | P |
| PUBLISHED | Approved and issued | S4, A | C |
| ARCHIVED | Superseded or closed, kept for the record | any | any |

| Suitability | Meaning |
|---|---|
| S0 | Work in progress (not for sharing) |
| S1 | Suitable for coordination |
| S2 | Suitable for information |
| S3 | Suitable for review and comment |
| S4 | Suitable for stage approval |
| A | Authorised and accepted |

Revisions: `P01, P02 ...` are preliminary (before approval). `C01, C02 ...` are contractual (approved).

## 4. Register metadata

Every document has one row in the register. All fields are required except `review_due` on ARCHIVED documents.

| Field | Content |
|---|---|
| `record_id` | Unique register row ID (`REG-0001`) |
| `file_name` | As in section 1 |
| `title` | Human-readable title |
| `originator`, `section`, `doc_type`, `discipline`, `number`, `revision` | Must match the file name exactly |
| `status`, `suitability` | As in section 3 |
| `author`, `author_email` | Person responsible (personal data, see doc 03) |
| `created`, `last_modified`, `review_due` | ISO dates (`YYYY-MM-DD`); `last_modified` is never before `created` |
| `content_hash` | Fingerprint of the file content, used to find identical copies |
| `contains_personal_data` | `Y` or `N` |
| `classification` | `Internal` or `Restricted`. Anything with `contains_personal_data = Y` is `Restricted` |
| `retention_class` | `R12` or `R6`, set by document type (doc 03) |

## 5. What the audit checks

The register audit (`cde/audit.py`) tests each of these rules.

| Check | Rule |
|---|---|
| `missing_metadata` | Required fields are filled in |
| `filename_pattern` | File name matches the pattern in section 1 |
| `filename_metadata_mismatch` | Codes and revision in the file name equal the register fields |
| `unknown_code` | Originator, section, type, discipline, status, suitability and revision format are valid |
| `status_consistency` | Suitability and revision prefix are allowed for the status |
| `duplicate_number` | No two records share originator, section, type, discipline, number and revision |
| `duplicate_content` | No two records share a content hash |
| `overdue_review` | Non-archived documents are not past their review date |
| `date_error` | Dates are valid, `last_modified` is not before `created`, `created` is not in the future |
| `personal_data_classification` | Personal data is classed Restricted |
| `retention_class` | Retention class matches the document type |
