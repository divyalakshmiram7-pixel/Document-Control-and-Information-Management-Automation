"""Load the naming and metadata standard and provide filename helpers."""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_STANDARD = ROOT / "config" / "standard.json"

REGISTER_FIELDS = [
    "record_id",
    "file_name",
    "title",
    "originator",
    "section",
    "doc_type",
    "discipline",
    "number",
    "revision",
    "status",
    "suitability",
    "author",
    "author_email",
    "created",
    "last_modified",
    "review_due",
    "content_hash",
    "contains_personal_data",
    "classification",
    "retention_class",
]

# review_due is also required, except for ARCHIVED documents (checked in audit.py).
REQUIRED_FIELDS = [f for f in REGISTER_FIELDS if f not in ("record_id", "review_due")]


def _loose(text: str) -> str:
    """Upper-case and strip everything except letters and digits."""
    return re.sub(r"[^A-Z0-9]", "", text.upper())


class Standard:
    """Wraps config/standard.json and the filename rules derived from it."""

    def __init__(self, data: dict):
        self.data = data
        self.project_code: str = data["project_code"]
        self.originators: dict = data["originators"]
        self.sections: dict = data["sections"]
        self.types: dict = data["types"]
        self.disciplines: dict = data["disciplines"]
        self.statuses: list = data["statuses"]
        self.suitability: dict = data["suitability"]
        self.status_rules: dict = data["status_rules"]
        self.retention_by_type: dict = data["retention"]["by_type"]
        self.classifications: list = data["classifications"]
        code = re.escape(self.project_code)
        self._pattern = re.compile(
            rf"^{code}-(?P<originator>[A-Z]{{3}})-(?P<section>[A-Z0-9]{{2}})"
            rf"-(?P<doc_type>[A-Z]{{2}})-(?P<discipline>[A-Z]{{2}})"
            rf"-(?P<number>\d{{4}})_(?P<revision>[PC]\d{{2}})\.(?P<ext>[a-z0-9]{{2,4}})$"
        )

    @classmethod
    def load(cls, path: Path | str = DEFAULT_STANDARD) -> "Standard":
        with open(path, encoding="utf-8") as fh:
            return cls(json.load(fh))

    # ------------------------------------------------------------------ filenames
    def parse_filename(self, name: str) -> dict | None:
        """Return the fields encoded in a file name, or None if it does not conform."""
        match = self._pattern.match(name or "")
        return match.groupdict() if match else None

    def build_filename(self, originator, section, doc_type, discipline, number, revision, ext="pdf") -> str:
        return (
            f"{self.project_code}-{originator}-{section}-{doc_type}-{discipline}"
            f"-{number}_{revision}.{ext}"
        )

    def expected_filename(self, rec: dict) -> str | None:
        """File name implied by the register metadata, or None if metadata is unusable."""
        match = re.search(r"\.([A-Za-z0-9]{2,4})$", (rec.get("file_name") or "").strip())
        ext = match.group(1).lower() if match else "pdf"
        name = self.build_filename(
            rec.get("originator", ""),
            rec.get("section", ""),
            rec.get("doc_type", ""),
            rec.get("discipline", ""),
            rec.get("number", ""),
            rec.get("revision", ""),
            ext,
        )
        return name if self.parse_filename(name) else None

    def suggest_filename_fix(self, rec: dict) -> str | None:
        """Propose a corrected file name when the problem is purely cosmetic.

        Cosmetic means the name, ignoring case and punctuation, is the expected name,
        or is the expected name with the revision missing. Anything else (extra words,
        different codes) needs a human decision, so None is returned.
        """
        expected = self.expected_filename(rec)
        if expected is None:
            return None
        name = (rec.get("file_name") or "").strip()
        stem = name.rsplit(".", 1)[0] if re.search(r"\.[A-Za-z0-9]{2,4}$", name) else name
        expected_stem = expected.rsplit(".", 1)[0]
        revision = rec.get("revision", "")
        if _loose(stem) == _loose(expected_stem) or _loose(expected_stem) == _loose(stem) + _loose(revision):
            return expected
        return None

    # ------------------------------------------------------------------ rules
    def expected_retention(self, doc_type: str) -> str | None:
        return self.retention_by_type.get(doc_type)
