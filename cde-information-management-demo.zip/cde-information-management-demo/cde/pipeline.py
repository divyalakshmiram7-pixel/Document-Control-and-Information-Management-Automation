"""Run the whole workflow: generate -> audit -> fix -> re-audit -> report.

    python -m cde.pipeline                 # defaults: seed 42, 120 documents, as-of 2026-11-12
    python -m cde.pipeline --seed 7 --documents 200
"""

from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path

from . import report
from .audit import FINDING_FIELDS, audit
from .fix import FIX_LOG_FIELDS, apply_fixes
from .generate import generate, write_register, write_rows
from .standard import ROOT, Standard


def run(out: Path = ROOT, seed: int = 42, n_documents: int = 120, as_of: date = date(2026, 11, 12)) -> dict:
    std = Standard.load()
    data_dir, reports_dir = out / "data", out / "reports"
    figures_dir = reports_dir / "figures"
    figures_dir.mkdir(parents=True, exist_ok=True)

    # 1. Synthetic register with planted errors (plus the answer key).
    records, truth = generate(std, seed=seed, n_documents=n_documents, as_of=as_of)
    write_register(records, data_dir / "register_raw.csv")
    write_rows(truth, data_dir / "ground_truth.csv", ["record_id", "check", "detail"])

    # 2. Audit the raw register.
    findings_before = audit(records, std, as_of)
    write_rows(findings_before, reports_dir / "findings_before.csv", FINDING_FIELDS)

    # 3. Apply the safe fixes and log every change.
    cleaned, fix_log = apply_fixes(records, findings_before, std)
    write_register(cleaned, data_dir / "register_clean.csv")
    write_rows(fix_log, reports_dir / "fix_log.csv", FIX_LOG_FIELDS)

    # 4. Re-audit: whatever is left goes to a person.
    findings_after = audit(cleaned, std, as_of)
    write_rows(findings_after, reports_dir / "exceptions.csv", FINDING_FIELDS)

    # 5. Metrics, evaluation against the planted errors, charts, report.
    metrics = report.compute_metrics(records, findings_before, fix_log, findings_after)
    evaluation = report.evaluate_against_truth(findings_before, truth)
    metrics["evaluation"] = evaluation
    (reports_dir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    write_rows(
        evaluation,
        reports_dir / "audit_evaluation.csv",
        ["check", "planted", "detected", "missed", "false_positives", "precision_pct", "recall_pct"],
    )
    report.chart_findings_by_check(metrics, figures_dir / "findings_by_check.png")
    report.chart_status(records, figures_dir / "records_by_status.png")
    report.chart_rate_by_originator(records, findings_before, std, figures_dir / "finding_rate_by_originator.png")
    report.write_markdown(metrics, evaluation, findings_after, as_of, reports_dir / "audit_report.md")
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--documents", type=int, default=120)
    parser.add_argument("--as-of", type=date.fromisoformat, default=date(2026, 11, 12))
    parser.add_argument("--out", type=Path, default=ROOT)
    args = parser.parse_args()
    m = run(args.out, args.seed, args.documents, args.as_of)
    print(
        f"{m['total_records']} records | before: {m['records_with_findings_before']} flagged "
        f"({m['record_error_rate_before_pct']}%) | auto-fixes: {m['auto_fixes_applied']} | "
        f"after: {m['records_with_findings_after']} flagged ({m['record_error_rate_after_pct']}%)"
    )


if __name__ == "__main__":
    main()
