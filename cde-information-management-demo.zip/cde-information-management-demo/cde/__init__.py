"""Information management demo: naming standard, register audit and reporting."""
