# 03. Data protection and retention note

This note explains how the register and the CDE handle personal data on the fictional Marlow Valley Tunnel
Scheme. It is a worked example for a portfolio. It is not legal advice, and the retention periods are
illustrative: on a real project they come from the contract, the organisation's retention policy and the
advice of its data protection officer.

All people and e-mail addresses in this repository are invented. E-mail addresses use the reserved
`example.test` domain.

## 1. Legislation

In the UK, personal data is governed by the UK GDPR and the Data Protection Act 2018. The points below apply
those rules to a project information register.

## 2. What personal data the register holds

| Data | Where | Why it is needed |
|---|---|---|
| Author name | `author` | Accountability: who is responsible for the document |
| Author work e-mail | `author_email` | To contact the author about the document |
| Names inside documents (letters, minutes, some risk assessments) | The documents themselves | Content of the record; flagged with `contains_personal_data = Y` |

The register holds no home addresses, dates of birth, ID numbers, health data or other special category data.
If a document does contain such data (for example an accident report), it is classed Restricted and handled
under the organisation's specific procedure.

## 3. Principles applied

| Principle | How the demo applies it |
|---|---|
| Lawfulness, fairness, transparency | Project staff are told the register records their name and work e-mail and why |
| Purpose limitation | Names and e-mails are used to run the project's information management, not for other purposes |
| Data minimisation | Only name and work e-mail are held per author; no personal contact details |
| Accuracy | The weekly audit checks owner and e-mail fields are present, and people are asked to correct them |
| Storage limitation | Retention classes below, applied by document type |
| Integrity and confidentiality | Documents with personal data are classed Restricted, with access limited to named people (doc 02, section 5) |
| Accountability | Fixes are logged with old and new values; the monthly report records actions taken |

## 4. How classification works

- Every register row has `contains_personal_data` (`Y` or `N`).
- If it is `Y`, `classification` must be `Restricted`. The audit raises a High severity finding if it is not, and
  the automatic fix sets it to Restricted. Raising the level is the safe direction, so it can be done without
  asking the author.
- Letters and meeting minutes are always flagged `Y`, because they name people.

## 5. Retention schedule (illustrative)

| Class | Applies to | Period | Notes |
|---|---|---|---|
| R12 | Drawings, reports, method statements, specifications, risk assessments, calculations | 12 years after project completion | Design and construction records are often kept for the length of the contractual liability period; many contracts use 6 or 12 years |
| R6 | Letters, meeting minutes | 6 years after project completion | Correspondence kept for the typical limitation period for contract claims |

The class is set from the document type. The audit raises a Low severity finding if the class does not match,
and the automatic fix applies the correct one. Where a document is kept beyond the point it would otherwise be
deleted (for example a legal hold), the reason and the approver are recorded.

At the end of the retention period, documents are reviewed for deletion. Personal data inside them is deleted
or anonymised unless there is a reason to keep it.

## 6. Individuals' rights and requests

If someone asks what personal data is held about them (a subject access request) or asks for correction or
deletion:

1. Pass the request to the data protection contact straight away. The legal deadline is generally one month,
   so it must not wait.
2. The Information Manager searches the register by `author` and `author_email`, and searches Restricted
   documents by name.
3. The data protection contact decides what is disclosed, corrected or deleted. The Information Manager carries
   out the technical steps and records them.

## 7. If personal data is shared or exposed by mistake

1. Stop the sharing (move the document back to WIP or Restricted, remove the link).
2. Tell the data protection contact immediately.
3. Record what happened, which documents and which people were involved, and who saw it.
4. The data protection contact decides whether to report to the Information Commissioner's Office. If a report
   is required it must normally be made within 72 hours of becoming aware of the breach.
5. Add the cause to the lessons learned (for example, a missing classification) and adjust the audit check if
   it would have caught the problem.

## 8. Limits of this demo

- The data is synthetic, so no real person is affected.
- A real CDE would enforce access controls in the system itself. The demo only checks that the classification
  field is right.
- Retention periods and the breach process must be confirmed against the real contract and policy before use.
