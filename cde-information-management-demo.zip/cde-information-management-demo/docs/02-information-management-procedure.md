# 02. Information management procedure

This procedure describes how information moves through the common data environment (CDE) on the fictional
Marlow Valley Tunnel Scheme. It is written so that a new team member can follow it without having to ask.

## 1. Roles

| Role | Responsibility |
|---|---|
| **Author** (originator's staff) | Names files correctly, completes the metadata, moves documents through the states, reviews their own documents by the review date |
| **Document controller** | Runs the weekly register audit, applies the safe fixes, chases the exceptions queue, keeps the transmittal log |
| **Information Manager** | Owns the standard and code lists, decides on new codes, resolves duplicate numbers, reports on information quality, trains users |
| **Project manager** | Receives the monthly quality report and escalates repeated problems with an originator |

## 2. Document lifecycle

```
 WIP  ->  SHARED  ->  PUBLISHED  ->  ARCHIVED
 (S0)    (S1-S3)      (S4, A)
 P rev    P rev        C rev
```

1. **WIP.** The author works in their own area. Nobody else can see the file. Revision `P01`, suitability `S0`.
2. **SHARED.** The author moves the file to the shared area for coordination or comment. Suitability `S1`, `S2`
   or `S3`. Revision stays `P` and increases each time a new version is shared.
3. **PUBLISHED.** After approval the document is issued. Suitability `S4` or `A`. Revision changes to `C01`
   and then increases with each approved change.
4. **ARCHIVED.** When superseded or when the work is closed, the document is archived and kept according to
   its retention class. Archived documents are read-only.

A published document is never edited in place. A change is a new revision.

## 3. Before a file goes into the CDE

The author checks the following. The upload check in the CDE (or, in this demo, the register audit) repeats it.

1. The file name follows the pattern in doc 01 and uses only approved codes.
2. The document number has not been used before for the same originator, section, type and discipline.
3. The register entry is complete and its codes match the file name.
4. Status, suitability and revision agree with each other.
5. If the file contains personal data, `contains_personal_data` is `Y` and the file is classed `Restricted`.
6. A review date is set (not required for archived documents).

## 4. Weekly register audit

Run by the document controller every week (and before any contractual submission).

1. Export the register and run the audit (`python -m cde.pipeline`, or the equivalent check in the live system).
2. Apply the automatic fixes. Each one is written to `fix_log.csv` with the old and new value, so any fix can
   be reversed.
3. Review the exceptions queue (`exceptions.csv`). Every item has a severity and a suggested action.
4. Send each exception to the person who can resolve it, with the target date from the table below.
5. Re-run the audit after the fixes. The count of open exceptions is the headline figure in the monthly report.

| Severity | Examples | Target to resolve |
|---|---|---|
| High | Duplicate number, file name and metadata disagree, personal data not Restricted, status inconsistent | 2 working days |
| Medium | Missing metadata, unknown code, overdue review, duplicate content | 5 working days |
| Low | Retention class wrong, date order wrong | 10 working days |

What counts as a safe automatic fix: only changes with exactly one correct answer that can be derived from the
standard (file name case and separators, retention class from document type, raising classification to
Restricted when personal data is flagged). Anything that needs a judgement, such as deciding which of two
duplicates is the real one, goes to a person.

## 5. Access

| Group | WIP | SHARED | PUBLISHED | ARCHIVED | Restricted documents |
|---|---|---|---|---|---|
| Authors | Own files only | Read and write own, read others | Read | Read | Only if named on the document |
| Project team | None | Read | Read | Read | No |
| Document controllers | Metadata only | Read and write metadata | Read and write metadata | Read | Metadata only, content by exception |
| Information Manager | Metadata only | Read and write | Read | Read and restore | Yes, for audit and data requests |
| Client team | None | By agreement | Read | None | No |

Access is removed on the day a person leaves the project, and the list is reviewed every quarter.

## 6. Transmittals

Every formal issue of published documents to another organisation is recorded in the transmittal log:
transmittal number, date, sender, recipient, the document numbers and revisions issued, and the reason for
issue. The log lets anyone answer "which revision did they have on that date?".

## 7. Training and onboarding

New starters get a 30-minute session covering the naming standard, the lifecycle above and how to read the
audit report, and a one-page quick reference of the file name pattern. The Information Manager reviews the
monthly report for repeat patterns by originator and offers a short refresher where the same error keeps
appearing.

## 8. Reporting

Monthly report to the project manager:

- Records audited and share with at least one finding, before and after fixes
- Findings by check and by originator
- Open exceptions by severity and age
- Actions taken (new codes, refreshers, access changes)
