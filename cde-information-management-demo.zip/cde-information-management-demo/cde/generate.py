"""Generate a synthetic document register, optionally seeded with known errors.

Everything here is fictional. People are made up from short name lists and every
e-mail address uses the reserved example.test domain. The generator records exactly
which errors it planted (the "ground truth") so the audit can be measured against it.
"""

from __future__ import annotations

import csv
import random
from datetime import date, timedelta
from pathlib import Path

from .standard import REGISTER_FIELDS, Standard

FIRST_NAMES = ["Amira", "Ben", "Chloe", "Dev", "Elena", "Femi", "Grace", "Hamza", "Isla", "Jon", "Kira", "Liam"]
LAST_NAMES = ["Ahmed", "Brooks", "Clarke", "Dhillon", "Evans", "Fraser", "Gill", "Hughes", "Iqbal", "Jones", "Khan", "Lowe"]

TOPICS = {
    "CV": ["Shaft headwall design", "Access road drainage", "Compound layout"],
    "ST": ["Segmental lining design", "Shaft base slab check", "Connection details"],
    "GE": ["Ground investigation summary", "Settlement assessment", "Groundwater monitoring"],
    "ME": ["Ventilation plan", "Pump arrangement", "Lifting equipment register"],
    "EL": ["Temporary power layout", "Lighting design", "Earthing arrangement"],
    "HS": ["Confined space procedure", "Emergency response plan", "Permit to work process"],
    "PM": ["Progress summary", "Interface schedule", "Change request log"],
    "SU": ["Control point survey", "As-built setting out", "Alignment verification"],
    "EN": ["Noise monitoring results", "Spoil management plan", "Ecology constraints"],
}

# (check name, number of records to plant it in)
ERROR_PLAN = [
    ("filename_pattern", 5),
    ("unknown_code", 3),
    ("filename_metadata_mismatch", 4),
    ("missing_metadata", 5),
    ("status_consistency", 5),
    ("overdue_review", 6),
    ("date_error", 3),
    ("personal_data_classification", 4),
    ("retention_class", 4),
]
DUPLICATE_NUMBER_PAIRS = 3
DUPLICATE_CONTENT_PAIRS = 3


def _topic_title(rng: random.Random, std: Standard, discipline: str, section: str) -> str:
    return f"{rng.choice(TOPICS[discipline])} - {std.sections[section]}"


def _person(rng: random.Random) -> tuple[str, str]:
    first, last = rng.choice(FIRST_NAMES), rng.choice(LAST_NAMES)
    return f"{first} {last}", f"{first}.{last}@example.test".lower()


def _make_clean_records(rng: random.Random, std: Standard, n: int, as_of: date) -> list[dict]:
    records: list[dict] = []
    used_keys: set[tuple] = set()
    statuses = std.statuses
    created_start = date(2025, 9, 1)
    while len(records) < n:
        originator = rng.choice(list(std.originators))
        section = rng.choice(list(std.sections))
        doc_type = rng.choice(list(std.types))
        discipline = rng.choice(list(std.disciplines))
        number = f"{rng.randint(1, 250):04d}"
        key = (originator, section, doc_type, discipline, number)
        if key in used_keys:
            continue
        used_keys.add(key)

        status = rng.choices(statuses, weights=[20, 30, 40, 10])[0]
        rule = std.status_rules[status]
        suitability = rng.choice(rule["suitability"] or list(std.suitability))
        prefix = rule["revision_prefix"] or rng.choice("PC")
        revision = f"{prefix}{rng.randint(1, 4):02d}"
        ext = rng.choice(["pdf", "pdf", "pdf", "docx", "xlsx", "dwg"])

        created = created_start + timedelta(days=rng.randint(0, 395))
        last_modified = created + timedelta(days=rng.randint(0, 120))
        last_modified = min(last_modified, as_of - timedelta(days=1))
        review_due = "" if status == "ARCHIVED" else (as_of + timedelta(days=rng.randint(14, 150))).isoformat()

        personal = "Y" if doc_type in ("LT", "MI") or rng.random() < 0.1 else "N"
        author, email = _person(rng)

        records.append(
            {
                "record_id": f"REG-{len(records) + 1:04d}",
                "file_name": std.build_filename(originator, section, doc_type, discipline, number, revision, ext),
                "title": _topic_title(rng, std, discipline, section),
                "originator": originator,
                "section": section,
                "doc_type": doc_type,
                "discipline": discipline,
                "number": number,
                "revision": revision,
                "status": status,
                "suitability": suitability,
                "author": author,
                "author_email": email,
                "created": created.isoformat(),
                "last_modified": last_modified.isoformat(),
                "review_due": review_due,
                "content_hash": f"{rng.getrandbits(64):016x}",
                "contains_personal_data": personal,
                "classification": "Restricted" if personal == "Y" else "Internal",
                "retention_class": std.expected_retention(doc_type),
            }
        )
    return records


# --------------------------------------------------------------------------- error injection
def _swap_filename_part(rec: dict, std: Standard, **changes) -> None:
    parsed = std.parse_filename(rec["file_name"])
    parsed.update(changes)
    rec["file_name"] = std.build_filename(
        parsed["originator"], parsed["section"], parsed["doc_type"],
        parsed["discipline"], parsed["number"], parsed["revision"], parsed["ext"],
    )


def _inject(check: str, rec: dict, rng: random.Random, std: Standard, as_of: date) -> None:
    if check == "filename_pattern":
        good = rec["file_name"]
        stem, ext = good.rsplit(".", 1)
        variant = rng.choice(["lowercase", "underscores", "no_revision", "extra_word", "lowercase"])
        if variant == "lowercase":
            rec["file_name"] = f"{stem.lower()}.{ext}"
        elif variant == "underscores":
            rec["file_name"] = f"{stem.replace('-', '_')}.{ext}"
        elif variant == "no_revision":
            rec["file_name"] = f"{stem.split('_')[0]}.{ext}"
        else:
            rec["file_name"] = f"{stem} FINAL.{ext}"

    elif check == "unknown_code":
        field, bad = rng.choice(
            [("originator", "XYZ"), ("section", "S9"), ("doc_type", "ZZ"), ("discipline", "QQ")]
        )
        rec[field] = bad
        _swap_filename_part(rec, std, **{field: bad})

    elif check == "filename_metadata_mismatch":
        field = rng.choice(["section", "discipline", "originator", "revision"])
        if field == "section":
            new = rng.choice([c for c in std.sections if c != rec["section"]])
        elif field == "discipline":
            new = rng.choice([c for c in std.disciplines if c != rec["discipline"]])
        elif field == "originator":
            new = rng.choice([c for c in std.originators if c != rec["originator"]])
        else:
            current = int(rec["revision"][1:])
            new = f"{rec['revision'][0]}{(current % 4) + 1:02d}"
        _swap_filename_part(rec, std, **{field: new})

    elif check == "missing_metadata":
        field = rng.choice(["title", "author", "author_email", "review_due"])
        if field == "review_due" and rec["status"] == "ARCHIVED":
            field = "title"
        rec[field] = ""

    elif check == "status_consistency":
        rule = std.status_rules[rec["status"]]
        if rng.random() < 0.5:
            wrong = [s for s in std.suitability if s not in rule["suitability"]]
            rec["suitability"] = rng.choice(wrong)
        else:
            new_prefix = "C" if rule["revision_prefix"] == "P" else "P"
            new_rev = f"{new_prefix}{rec['revision'][1:]}"
            rec["revision"] = new_rev
            _swap_filename_part(rec, std, revision=new_rev)

    elif check == "overdue_review":
        rec["review_due"] = (as_of - timedelta(days=rng.randint(5, 90))).isoformat()

    elif check == "date_error":
        created = date.fromisoformat(rec["created"])
        rec["last_modified"] = (created - timedelta(days=rng.randint(1, 30))).isoformat()

    elif check == "personal_data_classification":
        rec["contains_personal_data"] = "Y"
        rec["classification"] = "Internal"

    elif check == "retention_class":
        correct = rec["retention_class"]
        rec["retention_class"] = rng.choice([c for c in ("R6", "R12") if c != correct])

    else:  # pragma: no cover
        raise ValueError(check)


def _needs_live(check: str) -> bool:
    """Checks that only make sense for documents that are not archived."""
    return check in ("overdue_review", "status_consistency")


def generate(
    std: Standard,
    seed: int = 42,
    n_documents: int = 120,
    as_of: date = date(2026, 11, 12),
    inject_errors: bool = True,
) -> tuple[list[dict], list[dict]]:
    """Return (records, ground_truth). ground_truth rows are {record_id, check, detail}."""
    rng = random.Random(seed)
    records = _make_clean_records(rng, std, n_documents, as_of)
    truth: list[dict] = []
    if not inject_errors:
        return records, truth

    # Choose victims without replacement so each planted error has its own record.
    pool = list(range(len(records)))
    rng.shuffle(pool)

    def take(check: str) -> int:
        for pos, idx in enumerate(pool):
            if _needs_live(check) and records[idx]["status"] == "ARCHIVED":
                continue
            return pool.pop(pos)
        raise RuntimeError("not enough records to plant errors")

    # Reserve originals for the duplicate pairs first so they stay otherwise clean.
    dup_number_src = [take("duplicate_number") for _ in range(DUPLICATE_NUMBER_PAIRS)]
    dup_content_src = [take("duplicate_content") for _ in range(DUPLICATE_CONTENT_PAIRS)]

    for check, count in ERROR_PLAN:
        for _ in range(count):
            idx = take(check)
            rec = records[idx]
            _inject(check, rec, rng, std, as_of)
            truth.append({"record_id": rec["record_id"], "check": check, "detail": "planted"})

    next_id = len(records) + 1

    # Same document number and revision, different content: a numbering clash.
    for idx in dup_number_src:
        src = records[idx]
        clone = dict(src)
        clone["record_id"] = f"REG-{next_id:04d}"
        next_id += 1
        clone["title"] = src["title"] + " (updated)"
        clone["author"], clone["author_email"] = _person(rng)
        clone["content_hash"] = f"{rng.getrandbits(64):016x}"
        records.append(clone)
        for rid in (src["record_id"], clone["record_id"]):
            truth.append({"record_id": rid, "check": "duplicate_number", "detail": "planted pair"})

    # Same content filed twice under two different (valid) document numbers.
    used = {(r["originator"], r["section"], r["doc_type"], r["discipline"], r["number"]) for r in records}
    for idx in dup_content_src:
        src = records[idx]
        clone = dict(src)
        clone["record_id"] = f"REG-{next_id:04d}"
        next_id += 1
        while True:
            number = f"{rng.randint(251, 999):04d}"
            key = (src["originator"], src["section"], src["doc_type"], src["discipline"], number)
            if key not in used:
                used.add(key)
                break
        clone["number"] = number
        clone["file_name"] = std.build_filename(
            src["originator"], src["section"], src["doc_type"], src["discipline"], number,
            src["revision"], src["file_name"].rsplit(".", 1)[1],
        )
        records.append(clone)
        for rid in (src["record_id"], clone["record_id"]):
            truth.append({"record_id": rid, "check": "duplicate_content", "detail": "planted pair"})

    return records, truth


# --------------------------------------------------------------------------- csv helpers
def write_register(records: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=REGISTER_FIELDS)
        writer.writeheader()
        writer.writerows(records)


def read_register(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def write_rows(rows: list[dict], path: Path, fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
