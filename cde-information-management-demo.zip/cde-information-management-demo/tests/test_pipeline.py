from datetime import date

import pytest

from cde.audit import CHECKS, audit
from cde.fix import apply_fixes
from cde.generate import generate
from cde.report import evaluate_against_truth
from cde.standard import Standard

AS_OF = date(2026, 11, 12)


@pytest.fixture(scope="module")
def std():
    return Standard.load()


def test_clean_register_has_no_findings(std):
    """No planted errors means no findings: the checks do not raise false alarms."""
    records, truth = generate(std, seed=1, n_documents=150, as_of=AS_OF, inject_errors=False)
    assert truth == []
    assert audit(records, std, AS_OF) == []


@pytest.mark.parametrize("seed", [1, 2, 3, 42, 99])
def test_every_planted_error_is_found_and_nothing_extra(std, seed):
    records, truth = generate(std, seed=seed, n_documents=120, as_of=AS_OF)
    findings = audit(records, std, AS_OF)
    for row in evaluate_against_truth(findings, truth):
        assert row["missed"] == 0, row
        assert row["false_positives"] == 0, row


def test_every_check_is_exercised_by_the_generator(std):
    records, truth = generate(std, seed=42, n_documents=120, as_of=AS_OF)
    assert {t["check"] for t in truth} == set(CHECKS)


def test_fixes_remove_only_auto_fixable_findings(std):
    records, _ = generate(std, seed=42, n_documents=120, as_of=AS_OF)
    before = audit(records, std, AS_OF)
    cleaned, log = apply_fixes(records, before, std)
    after = audit(cleaned, std, AS_OF)

    fixable = {(f["record_id"], f["check"]) for f in before if f["auto_fixable"] == "Y"}
    remaining = {(f["record_id"], f["check"]) for f in after}
    before_keys = {(f["record_id"], f["check"]) for f in before}

    assert not (fixable & remaining) or all(k[1] == "filename_pattern" for k in fixable & remaining)
    assert remaining <= before_keys            # fixing never creates a new finding
    assert len(log) == len(before_keys - remaining)


def test_fixing_does_not_change_the_input(std):
    records, _ = generate(std, seed=42, n_documents=120, as_of=AS_OF)
    snapshot = [dict(r) for r in records]
    apply_fixes(records, audit(records, std, AS_OF), std)
    assert records == snapshot


def test_same_seed_gives_identical_output(std):
    a, ta = generate(std, seed=7, n_documents=80, as_of=AS_OF)
    b, tb = generate(std, seed=7, n_documents=80, as_of=AS_OF)
    assert a == b and ta == tb


def test_synthetic_emails_use_reserved_test_domain(std):
    records, _ = generate(std, seed=42, n_documents=120, as_of=AS_OF)
    assert all(r["author_email"].endswith("@example.test") for r in records if r["author_email"])
