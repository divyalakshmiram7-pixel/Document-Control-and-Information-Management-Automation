"""Metrics, evaluation against the planted errors, charts and the markdown report."""

from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from .audit import CHECKS  # noqa: E402

# Palette from the validated default set (slots 1 and 2, light mode).
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK_SECONDARY = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
BLUE = "#2a78d6"
ORANGE = "#eb6834"

plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["DejaVu Sans"],
        "axes.facecolor": SURFACE,
        "figure.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "text.color": INK,
        "axes.labelcolor": INK_SECONDARY,
        "xtick.color": MUTED,
        "ytick.color": INK_SECONDARY,
    }
)


def _pct(part: int, whole: int) -> float:
    return round(100 * part / whole, 1) if whole else 0.0


def compute_metrics(records, findings_before, fix_log, findings_after) -> dict:
    total = len(records)
    before_ids = {f["record_id"] for f in findings_before}
    after_ids = {f["record_id"] for f in findings_after}
    return {
        "total_records": total,
        "findings_before": len(findings_before),
        "records_with_findings_before": len(before_ids),
        "record_error_rate_before_pct": _pct(len(before_ids), total),
        "findings_by_check_before": dict(Counter(f["check"] for f in findings_before)),
        "auto_fixes_applied": len(fix_log),
        "auto_fixes_by_check": dict(Counter(f["check"] for f in fix_log)),
        "findings_after": len(findings_after),
        "records_with_findings_after": len(after_ids),
        "record_error_rate_after_pct": _pct(len(after_ids), total),
        "findings_by_check_after": dict(Counter(f["check"] for f in findings_after)),
        "findings_by_severity_after": dict(Counter(f["severity"] for f in findings_after)),
    }


def evaluate_against_truth(findings: list[dict], truth: list[dict]) -> list[dict]:
    """Compare the audit's findings with the errors the generator planted."""
    found = {(f["record_id"], f["check"]) for f in findings}
    planted = {(t["record_id"], t["check"]) for t in truth}
    rows = []
    for check in CHECKS:
        p = {k for k in planted if k[1] == check}
        d = {k for k in found if k[1] == check}
        tp = len(p & d)
        fp = len(d - p)
        fn = len(p - d)
        rows.append(
            {
                "check": check,
                "planted": len(p),
                "detected": tp,
                "missed": fn,
                "false_positives": fp,
                "precision_pct": _pct(tp, tp + fp) if (tp + fp) else 100.0,
                "recall_pct": _pct(tp, tp + fn) if (tp + fn) else 100.0,
            }
        )
    return rows


# ------------------------------------------------------------------------------ charts
def _style_axes(ax):
    for side in ("top", "right", "left"):
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.tick_params(length=0)
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def chart_findings_by_check(metrics: dict, path: Path) -> None:
    checks = sorted(CHECKS, key=lambda c: metrics["findings_by_check_before"].get(c, 0))
    before = [metrics["findings_by_check_before"].get(c, 0) for c in checks]
    after = [metrics["findings_by_check_after"].get(c, 0) for c in checks]
    labels = [c.replace("_", " ") for c in checks]
    ypos = range(len(checks))
    h = 0.34

    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    ax.barh([y + h / 2 + 0.02 for y in ypos], before, height=h, color=BLUE, label="Before auto-fix")
    ax.barh([y - h / 2 - 0.02 for y in ypos], after, height=h, color=ORANGE, label="Left for a person")
    for y, b, a in zip(ypos, before, after):
        ax.text(b + 0.15, y + h / 2 + 0.02, str(b), va="center", fontsize=9, color=INK_SECONDARY)
        ax.text(a + 0.15, y - h / 2 - 0.02, str(a), va="center", fontsize=9, color=INK_SECONDARY)
    ax.set_yticks(list(ypos))
    ax.set_yticklabels(labels, fontsize=10)
    ax.set_xlabel("Findings")
    ax.set_title("Findings by check: before and after automatic fixes", loc="left", fontsize=12, color=INK)
    ax.legend(frameon=False, loc="lower right", fontsize=9, labelcolor=INK_SECONDARY)
    ax.set_xlim(0, max(before) + 2)
    _style_axes(ax)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def chart_status(records: list[dict], path: Path) -> None:
    order = ["WIP", "SHARED", "PUBLISHED", "ARCHIVED"]
    counts = Counter(r["status"] for r in records)
    values = [counts.get(s, 0) for s in order]
    fig, ax = plt.subplots(figsize=(6.5, 3.8))
    ax.bar(order, values, width=0.5, color=BLUE)
    for x, v in zip(order, values):
        ax.text(x, v + 0.8, str(v), ha="center", fontsize=10, color=INK_SECONDARY)
    ax.set_title("Documents by CDE status", loc="left", fontsize=12, color=INK)
    ax.set_ylabel("Documents")
    ax.set_ylim(0, max(values) * 1.15)
    _style_axes(ax)
    ax.grid(axis="x", visible=False)
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def chart_rate_by_originator(records, findings_before, std, path: Path) -> None:
    # Records whose originator code is itself invalid are left out; they have no valid group.
    total = Counter(r["originator"] for r in records if r["originator"] in std.originators)
    flagged = defaultdict(set)
    rec_orig = {r["record_id"]: r["originator"] for r in records}
    for f in findings_before:
        if rec_orig[f["record_id"]] in total:
            flagged[rec_orig[f["record_id"]]].add(f["record_id"])
    codes = sorted(total, key=lambda c: _pct(len(flagged[c]), total[c]))
    rates = [_pct(len(flagged[c]), total[c]) for c in codes]
    labels = [f"{std.originators.get(c, c)} ({c})" for c in codes]
    fig, ax = plt.subplots(figsize=(7.5, 3.8))
    ax.barh(labels, rates, height=0.5, color=BLUE)
    for y, (r, c) in enumerate(zip(rates, codes)):
        ax.text(r + 0.5, y, f"{r:.0f}%  ({len(flagged[c])} of {total[c]})", va="center", fontsize=9, color=INK_SECONDARY)
    ax.set_xlim(0, max(rates) * 1.35)
    ax.set_xlabel("Share of that originator's records with at least one finding (before fixes)")
    ax.set_title("Records with findings by originator (errors planted at random)", loc="left", fontsize=12, color=INK)
    _style_axes(ax)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


# ------------------------------------------------------------------------------ markdown
def write_markdown(metrics: dict, evaluation: list[dict], exceptions: list[dict], as_of, path: Path) -> None:
    m = metrics
    lines = [
        "# Register audit report",
        "",
        f"Audit date: {as_of.isoformat()}. All data is synthetic.",
        "",
        "## Summary",
        "",
        f"- Records audited: **{m['total_records']}**",
        f"- Records with at least one finding before fixes: **{m['records_with_findings_before']}** "
        f"({m['record_error_rate_before_pct']}%)",
        f"- Automatic fixes applied: **{m['auto_fixes_applied']}**",
        f"- Records still needing a person after fixes: **{m['records_with_findings_after']}** "
        f"({m['record_error_rate_after_pct']}%)",
        "",
        "## Findings by check",
        "",
        "| Check | What it tests | Before | Fixed automatically | Left for a person |",
        "|---|---|---:|---:|---:|",
    ]
    for check, (_, description) in CHECKS.items():
        lines.append(
            f"| `{check}` | {description} | {m['findings_by_check_before'].get(check, 0)} "
            f"| {m['auto_fixes_by_check'].get(check, 0)} | {m['findings_by_check_after'].get(check, 0)} |"
        )
    lines += [
        "",
        "![Findings by check](figures/findings_by_check.png)",
        "",
        "## How well the audit finds known errors",
        "",
        "The generator plants a known set of errors and writes them to `data/ground_truth.csv`. "
        "The audit never reads that file; this table compares the two afterwards.",
        "",
        "| Check | Planted | Detected | Missed | False positives | Precision | Recall |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for e in evaluation:
        lines.append(
            f"| `{e['check']}` | {e['planted']} | {e['detected']} | {e['missed']} | {e['false_positives']} "
            f"| {e['precision_pct']}% | {e['recall_pct']}% |"
        )
    lines += [
        "",
        "## Exceptions queue (needs a person)",
        "",
        f"{len(exceptions)} findings remain after the automatic fixes. "
        "The full list with suggested actions is in `reports/exceptions.csv`. First ten, highest severity first:",
        "",
        "| Record | File | Check | Severity | Suggested action |",
        "|---|---|---|---|---|",
    ]
    rank = {"High": 0, "Medium": 1, "Low": 2}
    for f in sorted(exceptions, key=lambda x: (rank[x["severity"]], x["record_id"]))[:10]:
        lines.append(
            f"| {f['record_id']} | `{f['file_name']}` | {f['check']} | {f['severity']} | {f['suggested_action']} |"
        )
    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")
