# CDE information management demo

A small, runnable example of how information is organised, checked and reported on a large infrastructure
project. It uses a fictional tunnelling scheme (the Marlow Valley Tunnel Scheme) and entirely synthetic data.

It covers four things an information management team does every week:

1. **A standard**: how files are named, what metadata each document carries, and how status, suitability and
   revision relate (modelled on ISO 19650 ideas, simplified).
2. **A register audit**: 11 automated checks that find naming, metadata, duplication, review and data
   protection problems in a document register.
3. **Safe automatic fixes plus an exceptions queue**: mechanical problems are corrected and logged; anything
   that needs a judgement is routed to a person with a suggested action.
4. **Reporting**: a report and charts showing the state of the register before and after.

## Results from the included run

Seed 42, 126 register records (120 documents plus 6 deliberate duplicate copies), audit date 2026-11-12.

| Measure | Result |
|---|---|
| Records with at least one finding, before fixes | 51 of 126 (40.5%) |
| Fixed automatically and logged | 12 findings (file name format 4, retention class 4, personal data classification 4) |
| Records still needing a person | 39 of 126 (31.0%) |
| Planted errors found by the audit | 51 of 51, with 0 false positives |

![Findings by check](reports/figures/findings_by_check.png)

Open `reports/audit_report.md` for the full tables, `reports/exceptions.csv` for the queue with suggested
actions, and `reports/fix_log.csv` for every change made.

### How to read these numbers

- The register is synthetic and the errors in it were planted by the generator, at rates I chose. The 40.5%
  is not a typical real-world error rate. It is just the size of the test.
- The audit finds all 51 planted errors with no false alarms. That shows the checks do what they were written
  to do and do not complain about clean records (a test confirms this on error-free data). It does not show how
  they would perform on a real register, where errors are messier and the rules would need local tuning.
- Only 12 of the 51 problems are fixed automatically, on purpose. The other 39 need a decision, for example
  which of two documents with the same number is the real one. The aim is a short, clear list for a person, not
  a register that quietly rewrites itself.

## Quick start

Requires Python 3.10 or later.

```bash
git clone <your-repo-url>
cd cde-information-management-demo
pip install -r requirements.txt
python -m cde.pipeline        # regenerates data/ and reports/
python -m pytest              # runs the tests
```

Options: `python -m cde.pipeline --seed 7 --documents 200 --as-of 2026-12-01`. The same seed always gives
the same output.

## How it works

```
generate.py   builds a synthetic register and plants known errors (answer key: data/ground_truth.csv)
     |
audit.py      runs the 11 checks on the register (it never reads the answer key)
     |
fix.py        applies the three safe fixes, writes reports/fix_log.csv
     |
audit.py      re-runs on the fixed register -> reports/exceptions.csv
     |
report.py     metrics, comparison with the answer key, charts, reports/audit_report.md
```

The checks:

| Check | Tests |
|---|---|
| `filename_pattern` | File name matches the standard |
| `filename_metadata_mismatch` | Codes and revision in the name equal the register fields |
| `unknown_code` | Codes are on the approved lists |
| `missing_metadata` | Required fields are filled in |
| `status_consistency` | Status, suitability and revision agree |
| `duplicate_number` | No two records share a number and revision |
| `duplicate_content` | No identical content under two numbers |
| `overdue_review` | Review date not passed |
| `date_error` | Dates valid and in order |
| `personal_data_classification` | Personal data is classed Restricted |
| `retention_class` | Retention class matches document type |

## Repository contents

```
config/standard.json                      code lists and rules the audit uses
docs/01-naming-and-metadata-standard.md   the standard
docs/02-information-management-procedure.md  roles, lifecycle, weekly audit, access, reporting
docs/03-data-protection-and-retention.md  personal data handling and retention schedule
cde/                                      standard, generator, audit, fix, report, pipeline
tests/                                    23 tests
data/                                     register_raw.csv, register_clean.csv, ground_truth.csv
reports/                                  findings, fix log, exceptions, metrics, report, figures
```

## Design decisions

- **Rules live in one config file.** Adding a section or document type is a one-line change to
  `config/standard.json`, not a code change.
- **Every automatic change is logged with the old and new value**, so it can be checked or reversed.
- **Only changes with one correct answer are automated.** Raising a classification to Restricted is safe;
  guessing which duplicate to keep is not.
- **Measured against a known answer.** Planting the errors myself lets me report missed errors and false
  alarms instead of just saying the checks work.

## Limitations and what a live project would change

- The data is synthetic and the ground truth comes from the same author as the checks, so the 100% result is
  a consistency check, not an accuracy claim.
- The content hash is a stand-in. On a live project it would be calculated from the files in the CDE.
- Access control is documented (doc 02) but not enforced here. A real CDE enforces it in the system.
- The retention periods are illustrative and must come from the contract and organisation policy.
- The register would be pulled from the CDE through its export or API rather than a CSV, and the audit would
  run on a schedule, with the exceptions sent to the right people automatically.
- Next steps: check file names at upload time, add a transmittal log check, and trend the findings over time.

## Data note

All names, organisations, e-mail addresses and documents are invented. E-mail addresses use the reserved
`example.test` domain. The project is fictional and is not based on any real scheme, client or contractor.
