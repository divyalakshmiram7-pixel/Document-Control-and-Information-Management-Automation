import pytest

from cde.standard import Standard


@pytest.fixture(scope="module")
def std():
    return Standard.load()


def test_valid_filename_parses(std):
    parsed = std.parse_filename("MVT-ARC-S3-DR-CV-0012_P02.pdf")
    assert parsed == {
        "originator": "ARC", "section": "S3", "doc_type": "DR",
        "discipline": "CV", "number": "0012", "revision": "P02", "ext": "pdf",
    }


@pytest.mark.parametrize(
    "name",
    [
        "mvt-arc-s3-dr-cv-0012_p02.pdf",      # lower case
        "MVT_ARC_S3_DR_CV_0012_P02.pdf",      # underscores as separators
        "MVT-ARC-S3-DR-CV-0012.pdf",          # no revision
        "MVT-ARC-S3-DR-CV-0012_P02 FINAL.pdf",  # extra word
        "MVT-ARC-S3-DR-CV-12_P02.pdf",        # number not 4 digits
        "XXX-ARC-S3-DR-CV-0012_P02.pdf",      # wrong project code
        "",
    ],
)
def test_bad_filenames_rejected(std, name):
    assert std.parse_filename(name) is None


def test_build_and_parse_round_trip(std):
    name = std.build_filename("KTL", "ZZ", "MS", "HS", "0101", "C01", "docx")
    assert std.parse_filename(name)["originator"] == "KTL"
    assert name == "MVT-KTL-ZZ-MS-HS-0101_C01.docx"


def _rec(file_name):
    return {
        "file_name": file_name, "originator": "ARC", "section": "S3", "doc_type": "DR",
        "discipline": "CV", "number": "0012", "revision": "P02",
    }


def test_cosmetic_problems_get_an_automatic_fix(std):
    expected = "MVT-ARC-S3-DR-CV-0012_P02.pdf"
    assert std.suggest_filename_fix(_rec("mvt-arc-s3-dr-cv-0012_p02.pdf")) == expected
    assert std.suggest_filename_fix(_rec("MVT_ARC_S3_DR_CV_0012_P02.pdf")) == expected
    assert std.suggest_filename_fix(_rec("MVT-ARC-S3-DR-CV-0012.pdf")) == expected


def test_non_cosmetic_problems_are_left_for_a_person(std):
    assert std.suggest_filename_fix(_rec("MVT-ARC-S3-DR-CV-0012_P02 FINAL.pdf")) is None
    assert std.suggest_filename_fix(_rec("MVT-ARC-S3-DR-CV-0099_P02.pdf")) is None


def test_retention_lookup(std):
    assert std.expected_retention("DR") == "R12"
    assert std.expected_retention("LT") == "R6"
    assert std.expected_retention("ZZ") is None
