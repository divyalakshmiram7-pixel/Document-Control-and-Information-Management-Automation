# Register audit report

Audit date: 2026-11-12. All data is synthetic.

## Summary

- Records audited: **126**
- Records with at least one finding before fixes: **51** (40.5%)
- Automatic fixes applied: **12**
- Records still needing a person after fixes: **39** (31.0%)

## Findings by check

| Check | What it tests | Before | Fixed automatically | Left for a person |
|---|---|---:|---:|---:|
| `filename_pattern` | File name does not follow the naming standard | 5 | 4 | 1 |
| `filename_metadata_mismatch` | File name disagrees with the register metadata | 4 | 0 | 4 |
| `unknown_code` | A code is not in the approved code lists | 3 | 0 | 3 |
| `missing_metadata` | Required metadata is blank | 5 | 0 | 5 |
| `status_consistency` | Status, suitability and revision do not agree | 5 | 0 | 5 |
| `duplicate_number` | Two records share a document number and revision | 6 | 0 | 6 |
| `duplicate_content` | Identical content filed under different numbers | 6 | 0 | 6 |
| `overdue_review` | Review date has passed | 6 | 0 | 6 |
| `date_error` | Dates are invalid or out of order | 3 | 0 | 3 |
| `personal_data_classification` | Personal data is not classed as Restricted | 4 | 4 | 0 |
| `retention_class` | Retention class does not match the document type | 4 | 4 | 0 |

![Findings by check](figures/findings_by_check.png)

## How well the audit finds known errors

The generator plants a known set of errors and writes them to `data/ground_truth.csv`. The audit never reads that file; this table compares the two afterwards.

| Check | Planted | Detected | Missed | False positives | Precision | Recall |
|---|---:|---:|---:|---:|---:|---:|
| `filename_pattern` | 5 | 5 | 0 | 0 | 100.0% | 100.0% |
| `filename_metadata_mismatch` | 4 | 4 | 0 | 0 | 100.0% | 100.0% |
| `unknown_code` | 3 | 3 | 0 | 0 | 100.0% | 100.0% |
| `missing_metadata` | 5 | 5 | 0 | 0 | 100.0% | 100.0% |
| `status_consistency` | 5 | 5 | 0 | 0 | 100.0% | 100.0% |
| `duplicate_number` | 6 | 6 | 0 | 0 | 100.0% | 100.0% |
| `duplicate_content` | 6 | 6 | 0 | 0 | 100.0% | 100.0% |
| `overdue_review` | 6 | 6 | 0 | 0 | 100.0% | 100.0% |
| `date_error` | 3 | 3 | 0 | 0 | 100.0% | 100.0% |
| `personal_data_classification` | 4 | 4 | 0 | 0 | 100.0% | 100.0% |
| `retention_class` | 4 | 4 | 0 | 0 | 100.0% | 100.0% |

## Exceptions queue (needs a person)

39 findings remain after the automatic fixes. The full list with suggested actions is in `reports/exceptions.csv`. First ten, highest severity first:

| Record | File | Check | Severity | Suggested action |
|---|---|---|---|---|
| REG-0002 | `MVT-KTL-S6-LT-ME-0115_P02.dwg` | status_consistency | High | Author to correct the status, suitability or revision |
| REG-0003 | `MVT-MVC-S1-CA-HS-0155_P04.xlsx` | duplicate_number | High | Information Manager to reissue one number and reconcile the content |
| REG-0019 | `MVT-ARC-S1-SP-CV-0159_P03.pdf` | filename_metadata_mismatch | High | Check which is correct, then correct the file name or the register entry |
| REG-0032 | `MVT-MVC-S5-RP-SU-0107_C04.docx` | status_consistency | High | Author to correct the status, suitability or revision |
| REG-0035 | `MVT-ARC-S4-RA-ME-0070_P01.pdf` | filename_metadata_mismatch | High | Check which is correct, then correct the file name or the register entry |
| REG-0047 | `MVT-KTL-S3-CA-SU-0142_C03.pdf` | duplicate_number | High | Information Manager to reissue one number and reconcile the content |
| REG-0055 | `MVT-FGS-S6-LT-EL-0129_C01.xlsx` | status_consistency | High | Author to correct the status, suitability or revision |
| REG-0086 | `MVT-ARC-S5-RA-CV-0047_P03.pdf` | status_consistency | High | Author to correct the status, suitability or revision |
| REG-0092 | `MVT-FGS-S1-LT-ST-0063_P01.docx` | duplicate_number | High | Information Manager to reissue one number and reconcile the content |
| REG-0097 | `MVT-CLT-S6-MI-SU-0135_C03.pdf` | filename_metadata_mismatch | High | Check which is correct, then correct the file name or the register entry |
