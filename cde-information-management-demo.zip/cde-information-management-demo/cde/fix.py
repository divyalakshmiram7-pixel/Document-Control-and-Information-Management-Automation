"""Apply the safe, mechanical fixes and leave everything else for a person.

Only three kinds of problem are fixed automatically, because each has exactly one
correct answer that can be derived from the standard or from the record itself:
  * cosmetic file name problems (case, separators, missing revision)
  * retention class (derived from the document type)
  * classification of records flagged as containing personal data (raised to Restricted)
Everything else (duplicates, mismatches, dates, missing metadata ...) needs a human
decision and goes into the exceptions queue instead.
"""

from __future__ import annotations

from .standard import Standard

FIX_LOG_FIELDS = ["record_id", "check", "field", "old_value", "new_value", "reason"]


def apply_fixes(records: list[dict], findings: list[dict], std: Standard) -> tuple[list[dict], list[dict]]:
    fixed = [dict(r) for r in records]
    by_id = {r["record_id"]: r for r in fixed}
    log: list[dict] = []

    def record(rec_id, check, field, old, new, reason):
        log.append({"record_id": rec_id, "check": check, "field": field,
                    "old_value": old, "new_value": new, "reason": reason})

    for finding in findings:
        if finding["auto_fixable"] != "Y":
            continue
        rec = by_id[finding["record_id"]]
        check = finding["check"]

        if check == "filename_pattern":
            new_name = std.suggest_filename_fix(rec)
            if new_name and new_name != rec["file_name"]:
                record(rec["record_id"], check, "file_name", rec["file_name"], new_name,
                       "Normalised case/separators/revision to match metadata")
                rec["file_name"] = new_name

        elif check == "retention_class":
            expected = std.expected_retention(rec["doc_type"])
            if expected and rec["retention_class"] != expected:
                record(rec["record_id"], check, "retention_class", rec["retention_class"], expected,
                       f"Derived from document type {rec['doc_type']}")
                rec["retention_class"] = expected

        elif check == "personal_data_classification":
            if rec["classification"] != "Restricted":
                record(rec["record_id"], check, "classification", rec["classification"], "Restricted",
                       "Record contains personal data")
                rec["classification"] = "Restricted"

    return fixed, log
